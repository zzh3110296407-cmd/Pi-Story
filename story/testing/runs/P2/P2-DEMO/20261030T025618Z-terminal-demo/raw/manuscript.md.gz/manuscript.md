# P2 terminal check

## 第 1 章 The drowned harbor

The tide had come in over the lower town, and Ada rowed into it as though into a room where someone had just stopped speaking.

Bellwether had been a harbor once, in the ordinary sense. Now the water stood three feet deep in the streets, and the streets had gone on being streets anyway. Masts rose out of them at the corners, tied off to iron rings set in doorframes. A woman on an upper floor shook a rug over the sill and let it hang there, dripping onto a painted sign that said FISH, and under the sign there were fish, moving slow and unworried between the posts of what had been a market stall.

Ada counted the things she would need to remember. Twelve masts on the eastern reach. Nine windows lit. One bell tower, leaning, its reflection leaning further.

She had a letter in her coat, wrapped twice in oilcloth. She did not take it out. She had read it enough times on the crossing to know it by heart, and it did not improve with rereading, because it was in her mother's hand and her mother had been dead three years.

*Come to Bellwether before the spring tide. Ask for the man who wrote this. He will know you.*

That was all. No signature she recognized. The hand was her mother's down to the way the *w* in *wrote* came out with too many humps, and Ada had spent three years learning not to trust that particular comfort.

She shipped her oars and let the boat drift against a stone stair that went down into the water and did not come out again. A man stood at the top of it with a lantern and the expression of someone who had been standing there a while.

"Harbor's closed to arrivals," he said.

"I've arrived."

"Then the harbor's closed to you." He lowered the lantern. He was gray in the way of men who worked outdoors and had stopped enjoying it. "Rennick. Harbor master. You'll want to state your business before the light goes."

"Ada. I'm looking for a man."

"Most are." Hob Rennick came down two steps, which put him knee-deep. He did not seem to notice. "You'll want to be specific. We've had a great deal of water through here and not a great deal of record-keeping."

"He wrote to me."

"Then you have his name."

"That's the difficulty," Ada said. "He didn't put one."

Rennick looked at her the way a man looks at a bill he intends to dispute. "Letters come through the post office at High Bridge," he said. "If there's a question of a letter, that's a matter for the post office. If there's a question of a man, that's a matter for the constable, and the constable's boat went under in November, so I'd advise you to have a question of a letter."

"And if the letter was in a hand I know, from someone who can't have written it?"

"That," Rennick said, "would be a matter for the church."

"The church is under four feet of water."

"Then I'd advise you to take it up with the church." He lifted the lantern again, and the light went past her, out over the drowned street, and he said, more quietly, "You'll want lodging. Kell's, on the chandlery stair. She's the only one lets rooms to strangers and she'll want paying in advance, and don't tell her your business, because she'll sell it before you're down the stairs."

"That's a strange thing to tell a stranger."

"You asked for a man and wouldn't give a name," Rennick said. "I'd rather you were someone else's problem by morning." He turned up the steps. Then, without turning around: "The tide's early this year. Every year it's early. Don't trust the tables. Ask anyone."

Ada tied off at the chandlery stair and climbed.

The shop was up one flight and the room was up two, and the woman who met her at the top of the second was holding a lamp in one hand and a length of rope in the other, as though she had been interrupted in the middle of deciding something.

"Mira Kell," she said. "You'll be the one came in past the boom."

"There's a boom?"

"There's a boom." Mira smiled, warm as a lit window. "It's under the water now. That's the trouble with booms. Two nights, is it?"

"Two nights."

"Payment in advance. I don't sell the last of anything without a reason, and I don't let rooms on promises." She took the coins and did not count them where Ada could see, which was its own kind of counting. "There's a basin. There's a window that opens onto the tide, which some find a comfort and some don't. And there's a rule, which is that whatever you're here for, I'd hear it from you before I hear it from the street."

"I'm looking for a man who wrote to me."

Mira's hands went still on the rope. Only for a moment. "Half this town's written to someone," she said. "The other half wishes they hadn't. Was there a name on it?"

"No."

"Then you've come a long way for a poor return." She set the lamp on the sill. "Ask at the harbor office in the morning. Rennick keeps a ledger of every boat that ties up, and he keeps it in his head, which is the only place he thinks it's safe."

"He doesn't care for questions."

"Nobody here does." Mira opened the window. The tide came up close beneath it, black and easy, and the smell of it was salt and something older. "But he cares a great deal for the record looking orderly. Ask him something that would look disorderly in a ledger and he'll answer it just to be rid of you."

Ada slept badly and woke before the light.

She went down through the shop in the gray, past the coils of rope and the sealed tins and the shelves of things Mira Kell had decided not to sell the last of, and out onto the stair, and she took her boat south along the drowned street because the water was highest there and the current would tell her what the tide was doing.

It told her the tide was doing what it liked.

Past the leaning bell tower the street opened into what had been a basin, and there were boats in it, most of them sunk to the gunwales, one or two still riding. One rode high and clean and new-tarred, tied off to a ring on a warehouse wall, and there was nothing wrong with it at all, which in that place was the wrongest thing about it.

Ada brought her boat alongside and put her hand on the gunwale.

It was warm. Not sun-warm; there was no sun yet. Warm like something that had been sat in.

She looked into the boat. The oars were shipped neat. A coil of line lay in the bow, and a tin cup, and a folded coat, and on the thwart seat a hollow worn into the wood by use, and the hollow still held the shape of a man who had been there a moment ago and would be back.

She put her palm flat on the seat and held it there, counting. One. Two. Three. The warmth did not go away.

"Hello," she said, to the boat, to the water, to whatever had heard her come in past the boom.

Nothing answered. The masts stood in the streets and the water went on arguing with the almanac, and Ada sat with her hand on a warm seat in an empty boat, and did not leave the question alone.
